import { NavLink, Outlet } from 'react-router-dom';
import { PERSONAS, PersonaActionButton, usePersona, usePersonaAccess } from '../persona';

const primaryTabs = [
  { tab: 'workbasket' as const, label: 'Workbasket', path: '/forge/workbasket' },
  { tab: 'bugs' as const, label: 'Bugs', path: '/forge/bugs' },
  { tab: 'prs' as const, label: 'Pull Requests', path: '/forge/prs' },
  { tab: 'reports' as const, label: 'Reports', path: '/forge/reports' }
];

export function Layout() {
  const { me, persona, switchPersona, isLoading } = usePersona();
  const { canViewTab, policy } = usePersonaAccess();

  if (isLoading || !me || !persona || !policy) {
    return <div className="app-loader">Loading /me and persona policy...</div>;
  }

  return (
    <div className="shell">
      <header className="topbar">
        <div>
          <div className="brand">Forge</div>
          <div className="subtitle">Persona driven UI / APIs / Tabs / Actions</div>
        </div>

        <nav className="top-tabs">
          {primaryTabs
            .filter(item => canViewTab(item.tab))
            .map(item => (
              <NavLink key={item.tab} to={item.path} className={({ isActive }) => `top-tab ${isActive ? 'active' : ''}`}>
                {item.label}
              </NavLink>
            ))}
        </nav>

        <div className="user-box">
          <select value={persona} onChange={event => switchPersona(event.target.value as typeof persona)}>
            {PERSONAS.map(item => (
              <option key={item} value={item}>{item}</option>
            ))}
          </select>
          <div>
            <strong>{me.name}</strong>
            <span>{policy.label}</span>
          </div>
        </div>
      </header>

      <main className="main">
        <Outlet />
      </main>

      <footer className="footer-actions">
        <PersonaActionButton action="createBug">Create Bug</PersonaActionButton>
        <PersonaActionButton action="assignItem">Assign</PersonaActionButton>
        <PersonaActionButton action="requestReview">Request Review</PersonaActionButton>
        <PersonaActionButton action="approveRelease">Approve Release</PersonaActionButton>
      </footer>
    </div>
  );
}

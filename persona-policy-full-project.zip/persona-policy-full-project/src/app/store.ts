import { configureStore } from '@reduxjs/toolkit';
import { meApi } from '../persona/api/meApi';
import { workbasketApi } from '../features/workbasket/workbasketApi';
import { bugsApi } from '../features/bugs/bugsApi';
import { prsApi } from '../features/prs/prsApi';
import { reportsApi } from '../features/reports/reportsApi';

export const store = configureStore({
  reducer: {
    [meApi.reducerPath]: meApi.reducer,
    [workbasketApi.reducerPath]: workbasketApi.reducer,
    [bugsApi.reducerPath]: bugsApi.reducer,
    [prsApi.reducerPath]: prsApi.reducer,
    [reportsApi.reducerPath]: reportsApi.reducer
  },
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware().concat(
      meApi.middleware,
      workbasketApi.middleware,
      bugsApi.middleware,
      prsApi.middleware,
      reportsApi.middleware
    )
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

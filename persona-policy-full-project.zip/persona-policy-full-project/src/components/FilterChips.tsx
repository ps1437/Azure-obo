type Props = {
  chips: string[];
  active: string;
  onChange: (chip: string) => void;
};

export function FilterChips({ chips, active, onChange }: Props) {
  return (
    <div className="chips">
      {chips.map(chip => (
        <button
          key={chip}
          className={`chip ${active === chip ? 'active' : ''}`}
          onClick={() => onChange(chip)}
        >
          {chip}
        </button>
      ))}
    </div>
  );
}

import React from 'react';
import { Navigate } from 'react-router-dom';
import { usePersonaAccess } from '../persona';
import type { PageKey } from '../persona';

export function ProtectedRoute({ page, children }: { page: PageKey; children: React.ReactNode }) {
  const { canViewPage, policy } = usePersonaAccess();

  if (!policy) return <div className="page-loader">Loading persona...</div>;

  if (!canViewPage(page)) {
    return <Navigate to="/forbidden" replace />;
  }

  return <>{children}</>;
}

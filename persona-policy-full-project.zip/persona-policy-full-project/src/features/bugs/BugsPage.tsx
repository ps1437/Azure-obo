import { useState } from 'react';
import { EmptyState } from '../../components/EmptyState';
import { FilterChips } from '../../components/FilterChips';
import { StatusBadge } from '../../components/StatusBadge';
import { PersonaActionButton, usePersona } from '../../persona';
import { useGetBugsQuery } from './bugsApi';

export function BugsPage() {
  const { persona, policy } = usePersona();
  const [chip, setChip] = useState('All');
  const { data = [], isLoading } = useGetBugsQuery({ persona: persona!, filters: { _limit: 20 } }, { skip: !persona });
  const chips = policy?.chips.bugs ?? ['All'];
  const bugs = data.filter(item => chip === 'All' || item.priority === 'P1' || item.status === chip);

  return (
    <div className="page-card">
      <div className="page-header">
        <div><h1>Bugs</h1><p>Bug API and bug actions are persona driven.</p></div>
        <PersonaActionButton action="createBug">Create Bug</PersonaActionButton>
      </div>
      <FilterChips chips={chips} active={chip} onChange={setChip} />
      {isLoading ? <div className="page-loader">Loading bugs...</div> : null}
      {!isLoading && bugs.length === 0 ? <EmptyState title="No bugs" message="No bugs available for this persona." /> : null}
      <div className="simple-list">
        {bugs.map(bug => (
          <div key={bug.id} className="simple-row">
            <div><strong>{bug.title}</strong><p>{bug.description}</p></div>
            <StatusBadge value={bug.status} />
          </div>
        ))}
      </div>
    </div>
  );
}

import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import type { Persona, QueryValue } from '../../persona';
import { getPersonaPolicy, resolvePersonaApiUrl } from '../../persona';
import { normalizeWorkbasketResponse } from '../workbasket/workbasketAdapters';
import type { WorkbasketItem } from '../workbasket/workbasketTypes';

export const bugsApi = createApi({
  reducerPath: 'bugsApi',
  baseQuery: fetchBaseQuery({ baseUrl: 'https://jsonplaceholder.typicode.com' }),
  tagTypes: ['Bugs'],
  endpoints: builder => ({
    getBugs: builder.query<WorkbasketItem[], { persona: Persona; filters?: Record<string, QueryValue> }>({
      query: ({ persona, filters }) => {
        const policy = getPersonaPolicy(persona);
        return { url: resolvePersonaApiUrl(policy, 'bugs', filters), method: 'GET' };
      },
      transformResponse: (response: unknown, _meta, arg) =>
        normalizeWorkbasketResponse(arg.persona, response).filter(item => item.type === 'Bug' || item.priority === 'P1'),
      providesTags: (_result, _error, arg) => [{ type: 'Bugs', id: arg.persona }]
    })
  })
});

export const { useGetBugsQuery } = bugsApi;

import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import type { Persona, QueryValue } from '../../persona';
import { getPersonaPolicy, resolvePersonaApiUrl } from '../../persona';

export type ReportCard = {
  id: string;
  title: string;
  value: string;
  summary: string;
};

export const reportsApi = createApi({
  reducerPath: 'reportsApi',
  baseQuery: fetchBaseQuery({ baseUrl: 'https://jsonplaceholder.typicode.com' }),
  tagTypes: ['Reports'],
  endpoints: builder => ({
    getReports: builder.query<ReportCard[], { persona: Persona; filters?: Record<string, QueryValue> }>({
      query: ({ persona, filters }) => {
        const policy = getPersonaPolicy(persona);
        return { url: resolvePersonaApiUrl(policy, 'reports', filters), method: 'GET' };
      },
      transformResponse: (response: unknown, _meta, arg) => {
        const count = Array.isArray(response) ? response.length : 0;
        return [
          { id: `${arg.persona}-velocity`, title: 'Team Velocity', value: String(Math.min(count, 100)), summary: 'Derived from report API response.' },
          { id: `${arg.persona}-quality`, title: 'Quality Score', value: arg.persona === 'LEAD' ? '92%' : 'N/A', summary: 'Visible mainly for Lead persona.' },
          { id: `${arg.persona}-blocked`, title: 'Blocked Items', value: arg.persona === 'LEAD' ? '7' : 'Hidden', summary: 'Controlled by persona page visibility.' }
        ];
      },
      providesTags: (_result, _error, arg) => [{ type: 'Reports', id: arg.persona }]
    })
  })
});

export const { useGetReportsQuery } = reportsApi;

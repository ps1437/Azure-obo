import { PersonaGuard, usePersona } from '../../persona';
import { useGetReportsQuery } from './reportsApi';

export function ReportsPage() {
  const { persona } = usePersona();
  const { data = [], isLoading } = useGetReportsQuery({ persona: persona!, filters: { _limit: 10 } }, { skip: !persona });

  return (
    <div className="page-card">
      <div className="page-header">
        <div><h1>Reports</h1><p>Reports page is Lead-only in this sample.</p></div>
      </div>
      {isLoading ? <div className="page-loader">Loading reports...</div> : null}
      <PersonaGuard component="reports.teamHealthCard">
        <div className="report-grid">
          {data.map(card => (
            <div key={card.id} className="report-card">
              <label>{card.title}</label>
              <strong>{card.value}</strong>
              <p>{card.summary}</p>
            </div>
          ))}
        </div>
      </PersonaGuard>
    </div>
  );
}

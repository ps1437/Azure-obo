import { useMemo, useState } from 'react';
import { EmptyState } from '../../components/EmptyState';
import { FilterChips } from '../../components/FilterChips';
import { StatusBadge } from '../../components/StatusBadge';
import { PersonaActionButton, PersonaGuard, usePersona, usePersonaAccess } from '../../persona';
import { useGetWorkbasketQuery } from './workbasketApi';
import type { WorkbasketItem } from './workbasketTypes';

const detailTabs = [
  { tab: 'overview' as const, page: 'forge.workbasket.detail.overview' as const, label: 'Overview' },
  { tab: 'activity' as const, page: 'forge.workbasket.detail.activity' as const, label: 'Activity' },
  { tab: 'comments' as const, page: 'forge.workbasket.detail.comments' as const, label: 'Comments' },
  { tab: 'attachments' as const, page: 'forge.workbasket.detail.attachments' as const, label: 'Attachments' },
  { tab: 'approvals' as const, page: 'forge.workbasket.detail.approvals' as const, label: 'Approvals' }
];

export function WorkbasketPage() {
  const { persona, policy } = usePersona();
  const { canViewTab } = usePersonaAccess();
  const [search, setSearch] = useState('');
  const [activeChip, setActiveChip] = useState('All');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [activeDetailTab, setActiveDetailTab] = useState('overview');

  const { data = [], isLoading, isFetching, error } = useGetWorkbasketQuery(
    { persona: persona!, filters: { _limit: 25 } },
    { skip: !persona }
  );

  const chips = policy?.chips.workbasket ?? ['All'];

  const filteredItems = useMemo(() => {
    return data.filter(item => {
      const matchesSearch =
        item.title.toLowerCase().includes(search.toLowerCase()) ||
        item.description.toLowerCase().includes(search.toLowerCase());
      const matchesChip = activeChip === 'All' || item.type === activeChip || item.status === activeChip;
      return matchesSearch && matchesChip;
    });
  }, [data, search, activeChip]);

  const selectedItem = useMemo<WorkbasketItem | undefined>(() => {
    return filteredItems.find(item => item.id === selectedId) ?? filteredItems[0];
  }, [filteredItems, selectedId]);

  return (
    <div className="workbasket-layout">
      <aside className="left-panel">
        <PersonaGuard component="workbasket.leftPanel">
          <div className="panel-title-row">
            <div>
              <h2>My Tasks</h2>
              <p>{persona} view · {filteredItems.length} items</p>
            </div>
            {isFetching && <span className="sync-dot">Sync</span>}
          </div>

          <PersonaGuard component="workbasket.searchBox">
            <input
              className="search-input"
              value={search}
              onChange={event => setSearch(event.target.value)}
              placeholder="Search work item, bug, PR..."
            />
          </PersonaGuard>

          <PersonaGuard component="workbasket.filterChips">
            <FilterChips chips={chips} active={activeChip} onChange={setActiveChip} />
          </PersonaGuard>

          {isLoading && <div className="page-loader">Loading workbasket...</div>}
          {error && <div className="error-box">Failed to load workbasket.</div>}

          <div className="item-list">
            {filteredItems.map(item => (
              <button
                key={item.id}
                onClick={() => setSelectedId(item.id)}
                className={`item-card ${selectedItem?.id === item.id ? 'active' : ''}`}
              >
                <div className="item-card-top">
                  <span className="item-type">{item.type}</span>
                  <StatusBadge value={item.status} />
                </div>
                <strong>{item.title}</strong>
                <p>{item.description}</p>
                <div className="item-meta">
                  <span>{item.priority}</span>
                  <span>{item.assignee}</span>
                </div>
              </button>
            ))}
          </div>
        </PersonaGuard>
      </aside>

      <section className="detail-panel">
        {!selectedItem ? (
          <EmptyState title="No item selected" message="Select a task from the left side." />
        ) : (
          <>
            <PersonaGuard component="workbasket.detailHeader">
              <div className="detail-header">
                <div>
                  <span className="item-type big">{selectedItem.type}</span>
                  <h1>{selectedItem.title}</h1>
                  <p>{selectedItem.description}</p>
                </div>
                <div className="detail-actions">
                  <PersonaActionButton action="startWork">Start Work</PersonaActionButton>
                  <PersonaActionButton action="addComment">Add Comment</PersonaActionButton>
                  <PersonaActionButton action="assignItem">Assign</PersonaActionButton>
                  <PersonaActionButton action="approveRelease">Approve</PersonaActionButton>
                </div>
              </div>
            </PersonaGuard>

            <div className="detail-tabs">
              {detailTabs
                .filter(item => canViewTab(item.tab))
                .map(item => (
                  <button
                    key={item.tab}
                    className={`detail-tab ${activeDetailTab === item.tab ? 'active' : ''}`}
                    onClick={() => setActiveDetailTab(item.tab)}
                  >
                    {item.label}
                  </button>
                ))}
            </div>

            <div className="detail-body">
              {activeDetailTab === 'overview' && (
                <PersonaGuard page="forge.workbasket.detail.overview">
                  <Overview item={selectedItem} />
                </PersonaGuard>
              )}

              {activeDetailTab === 'activity' && (
                <PersonaGuard page="forge.workbasket.detail.activity">
                  <Timeline />
                </PersonaGuard>
              )}

              {activeDetailTab === 'comments' && (
                <PersonaGuard page="forge.workbasket.detail.comments">
                  <Comments />
                </PersonaGuard>
              )}

              {activeDetailTab === 'attachments' && (
                <PersonaGuard page="forge.workbasket.detail.attachments">
                  <Attachments />
                </PersonaGuard>
              )}

              {activeDetailTab === 'approvals' && (
                <PersonaGuard page="forge.workbasket.detail.approvals">
                  <Approvals />
                </PersonaGuard>
              )}
            </div>
          </>
        )}
      </section>
    </div>
  );
}

function Overview({ item }: { item: WorkbasketItem }) {
  return (
    <div className="overview-grid">
      <div className="info-card"><label>Status</label><strong>{item.status}</strong></div>
      <div className="info-card"><label>Priority</label><strong>{item.priority}</strong></div>
      <div className="info-card"><label>Assignee</label><strong>{item.assignee}</strong></div>
      <PersonaGuard component="workbasket.qaEvidence">
        <div className="info-card accent"><label>QA Evidence</label><strong>Test evidence required</strong></div>
      </PersonaGuard>
      <PersonaGuard component="workbasket.devChecklist">
        <div className="info-card accent"><label>Dev Checklist</label><strong>Code + Unit test + PR</strong></div>
      </PersonaGuard>
      <PersonaGuard component="workbasket.leadSummary">
        <div className="info-card accent"><label>Lead Summary</label><strong>Team impact review</strong></div>
      </PersonaGuard>
    </div>
  );
}

function Timeline() {
  return <div className="placeholder-card">Activity API tab is visible only when the persona policy allows it.</div>;
}

function Comments() {
  return <div className="placeholder-card">Comments area. Add comment action is policy driven.</div>;
}

function Attachments() {
  return <div className="placeholder-card">Attachments are visible for QA, hidden for DEV, and not configured for LEAD in this sample.</div>;
}

function Approvals() {
  return <div className="placeholder-card">Approval panel is Lead-only. Backend should also enforce approval permissions.</div>;
}

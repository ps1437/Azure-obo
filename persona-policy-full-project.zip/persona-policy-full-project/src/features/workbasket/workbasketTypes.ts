export type WorkbasketType = 'Bug' | 'Story' | 'Task' | 'PR' | 'Blocked';

export type WorkbasketItem = {
  id: string;
  title: string;
  type: WorkbasketType;
  status: 'New' | 'Active' | 'Blocked' | 'Closed';
  priority: 'P1' | 'P2' | 'P3';
  assignee: string;
  description: string;
  raw?: unknown;
};

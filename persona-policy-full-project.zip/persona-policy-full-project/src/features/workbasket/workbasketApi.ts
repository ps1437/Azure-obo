import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import type { Persona, QueryValue } from '../../persona';
import { getPersonaPolicy, resolvePersonaApiUrl } from '../../persona';
import { normalizeWorkbasketResponse } from './workbasketAdapters';
import type { WorkbasketItem } from './workbasketTypes';

type Args = {
  persona: Persona;
  filters?: Record<string, QueryValue>;
};

export const workbasketApi = createApi({
  reducerPath: 'workbasketApi',
  baseQuery: fetchBaseQuery({ baseUrl: 'https://jsonplaceholder.typicode.com' }),
  tagTypes: ['Workbasket'],
  endpoints: builder => ({
    getWorkbasket: builder.query<WorkbasketItem[], Args>({
      query: ({ persona, filters }) => {
        const policy = getPersonaPolicy(persona);
        return { url: resolvePersonaApiUrl(policy, 'workbasket', filters), method: 'GET' };
      },
      transformResponse: (response: unknown, _meta, arg) => normalizeWorkbasketResponse(arg.persona, response),
      providesTags: (_result, _error, arg) => [{ type: 'Workbasket', id: arg.persona }]
    })
  })
});

export const { useGetWorkbasketQuery } = workbasketApi;

import type { Persona } from '../../persona';
import type { WorkbasketItem, WorkbasketType } from './workbasketTypes';

type JsonPlaceholderPost = {
  userId: number;
  id: number;
  title: string;
  body: string;
};

const typeCycle: WorkbasketType[] = ['Bug', 'Story', 'Task', 'PR', 'Blocked'];

export function normalizeWorkbasketResponse(persona: Persona, response: unknown): WorkbasketItem[] {
  const items = Array.isArray(response) ? (response as JsonPlaceholderPost[]) : [];

  return items.slice(0, 18).map((item, index) => ({
    id: `${persona}-${item.id}`,
    title: item.title,
    type: typeCycle[index % typeCycle.length],
    status: index % 5 === 0 ? 'Blocked' : index % 3 === 0 ? 'Closed' : index % 2 === 0 ? 'Active' : 'New',
    priority: index % 3 === 0 ? 'P1' : index % 3 === 1 ? 'P2' : 'P3',
    assignee: persona === 'QA' ? 'QA Team' : persona === 'DEV' ? 'Dev User' : 'Platform Team',
    description: item.body,
    raw: item
  }));
}

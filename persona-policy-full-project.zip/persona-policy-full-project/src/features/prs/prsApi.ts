import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import type { Persona, QueryValue } from '../../persona';
import { getPersonaPolicy, resolvePersonaApiUrl } from '../../persona';
import { normalizeWorkbasketResponse } from '../workbasket/workbasketAdapters';
import type { WorkbasketItem } from '../workbasket/workbasketTypes';

export const prsApi = createApi({
  reducerPath: 'prsApi',
  baseQuery: fetchBaseQuery({ baseUrl: 'https://jsonplaceholder.typicode.com' }),
  tagTypes: ['PRs'],
  endpoints: builder => ({
    getPullRequests: builder.query<WorkbasketItem[], { persona: Persona; filters?: Record<string, QueryValue> }>({
      query: ({ persona, filters }) => {
        const policy = getPersonaPolicy(persona);
        return { url: resolvePersonaApiUrl(policy, 'prs', filters), method: 'GET' };
      },
      transformResponse: (response: unknown, _meta, arg) =>
        normalizeWorkbasketResponse(arg.persona, response).map(item => ({ ...item, type: 'PR' as const })),
      providesTags: (_result, _error, arg) => [{ type: 'PRs', id: arg.persona }]
    })
  })
});

export const { useGetPullRequestsQuery } = prsApi;

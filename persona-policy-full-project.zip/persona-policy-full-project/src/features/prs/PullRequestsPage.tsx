import { EmptyState } from '../../components/EmptyState';
import { PersonaActionButton, usePersona } from '../../persona';
import { useGetPullRequestsQuery } from './prsApi';

export function PullRequestsPage() {
  const { persona } = usePersona();
  const { data = [], isLoading } = useGetPullRequestsQuery({ persona: persona!, filters: { _limit: 12 } }, { skip: !persona });

  return (
    <div className="page-card">
      <div className="page-header">
        <div><h1>Pull Requests</h1><p>DEV and LEAD can see this page. QA is blocked by route policy.</p></div>
        <PersonaActionButton action="requestReview">Request Review</PersonaActionButton>
      </div>
      {isLoading ? <div className="page-loader">Loading pull requests...</div> : null}
      {!isLoading && data.length === 0 ? <EmptyState title="No PRs" message="No PR data available." /> : null}
      <div className="kanban-grid">
        {data.slice(0, 9).map(pr => (
          <div key={pr.id} className="kanban-card">
            <span className="item-type">PR</span>
            <strong>{pr.title}</strong>
            <p>{pr.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

import { Navigate, Route, Routes } from 'react-router-dom';
import { ProtectedRoute } from '../components/ProtectedRoute';
import { BugsPage } from '../features/bugs/BugsPage';
import { PullRequestsPage } from '../features/prs/PullRequestsPage';
import { ReportsPage } from '../features/reports/ReportsPage';
import { WorkbasketPage } from '../features/workbasket/WorkbasketPage';
import { Layout } from '../layout/Layout';

export function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/forge/workbasket" replace />} />
      <Route path="/forge" element={<Layout />}>
        <Route index element={<Navigate to="/forge/workbasket" replace />} />
        <Route path="workbasket" element={<ProtectedRoute page="forge.workbasket"><WorkbasketPage /></ProtectedRoute>} />
        <Route path="bugs" element={<ProtectedRoute page="forge.bugs"><BugsPage /></ProtectedRoute>} />
        <Route path="prs" element={<ProtectedRoute page="forge.prs"><PullRequestsPage /></ProtectedRoute>} />
        <Route path="reports" element={<ProtectedRoute page="forge.reports"><ReportsPage /></ProtectedRoute>} />
      </Route>
      <Route path="/forbidden" element={<ForbiddenPage />} />
      <Route path="*" element={<Navigate to="/forge/workbasket" replace />} />
    </Routes>
  );
}

function ForbiddenPage() {
  return (
    <div className="forbidden-page">
      <h1>403</h1>
      <p>This page is hidden for the selected persona.</p>
      <a href="/forge/workbasket">Go to Workbasket</a>
    </div>
  );
}

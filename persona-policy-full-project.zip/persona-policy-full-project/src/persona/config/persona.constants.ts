import type { Persona } from '../types/persona.types';

export const PERSONAS: Persona[] = ['QA', 'DEV', 'LEAD'];

import type { ApiKey, Persona, PersonaPolicy } from '../types/persona.types';

export const defaultApiUrls: Record<ApiKey, string> = {
  workbasket: '/posts',
  workitem: '/posts',
  bugs: '/posts?type=bug',
  prs: '/posts?type=pr',
  reports: '/posts',
  activity: '/comments',
  comments: '/comments',
  attachments: '/photos'
};

export const personaPolicyConfig: Record<Persona, PersonaPolicy> = {
  QA: {
    persona: 'QA',
    label: 'QA Persona',
    defaultRoute: '/forge/workbasket',
    permissions: [
      'WORKBASKET_VIEW',
      'BUG_VIEW',
      'BUG_CREATE',
      'BUG_CLOSE',
      'COMMENT_ADD',
      'ATTACHMENT_UPLOAD'
    ],
    pages: [
      'forge.workbasket',
      'forge.bugs',
      'forge.workbasket.detail.overview',
      'forge.workbasket.detail.activity',
      'forge.workbasket.detail.comments',
      'forge.workbasket.detail.attachments'
    ],
    tabs: ['workbasket', 'bugs', 'overview', 'activity', 'comments', 'attachments'],
    components: [
      'workbasket.leftPanel',
      'workbasket.searchBox',
      'workbasket.filterChips',
      'workbasket.detailHeader',
      'workbasket.qaEvidence'
    ],
    actions: {
      createBug: { enabled: true, permission: 'BUG_CREATE' },
      closeBug: { enabled: true, permission: 'BUG_CLOSE' },
      addComment: { enabled: true, permission: 'COMMENT_ADD' },
      uploadAttachment: { enabled: true, permission: 'ATTACHMENT_UPLOAD' },
      approveRelease: {
        enabled: false,
        permission: 'RELEASE_APPROVE',
        reason: 'Only Lead can approve release.'
      },
      assignItem: {
        enabled: false,
        permission: 'ITEM_ASSIGN',
        reason: 'QA can comment and close bugs but cannot assign team items.'
      }
    },
    apis: {
      workbasket: '/posts?userId=1&team=true',
      workitem: '/posts?userId=1&team=true',
      bugs: '/posts?userId=1&type=bug',
      activity: '/comments?postId=1',
      comments: '/comments?postId=1',
      attachments: '/photos?albumId=1'
    },
    chips: {
      workbasket: ['All', 'Bug', 'Story', 'Task'],
      bugs: ['All', 'Critical', 'Regression', 'UI']
    }
  },

  DEV: {
    persona: 'DEV',
    label: 'Developer Persona',
    defaultRoute: '/forge/workbasket',
    permissions: ['WORKBASKET_VIEW', 'BUG_VIEW', 'PR_VIEW', 'COMMENT_ADD'],
    pages: [
      'forge.workbasket',
      'forge.bugs',
      'forge.prs',
      'forge.workbasket.detail.overview',
      'forge.workbasket.detail.activity',
      'forge.workbasket.detail.comments'
    ],
    tabs: ['workbasket', 'bugs', 'prs', 'overview', 'activity', 'comments'],
    components: [
      'workbasket.leftPanel',
      'workbasket.searchBox',
      'workbasket.filterChips',
      'workbasket.detailHeader',
      'workbasket.devChecklist'
    ],
    actions: {
      startWork: { enabled: true },
      requestReview: { enabled: true, permission: 'PR_VIEW' },
      addComment: { enabled: true, permission: 'COMMENT_ADD' },
      createBug: {
        enabled: false,
        permission: 'BUG_CREATE',
        reason: 'Developer can view bugs but cannot create QA bugs.'
      },
      approveRelease: {
        enabled: false,
        permission: 'RELEASE_APPROVE',
        reason: 'Only Lead can approve release.'
      }
    },
    apis: {
      workbasket: '/posts?userId=2&assignedToMe=true',
      workitem: '/posts?userId=2&assignedToMe=true',
      bugs: '/posts?userId=2&type=bug',
      prs: '/posts?userId=2&type=pr',
      activity: '/comments?postId=2',
      comments: '/comments?postId=2'
    },
    chips: {
      workbasket: ['All', 'Task', 'PR', 'Bug'],
      prs: ['All', 'Review', 'Created By Me', 'Blocked']
    }
  },

  LEAD: {
    persona: 'LEAD',
    label: 'Lead Persona',
    defaultRoute: '/forge/workbasket',
    permissions: [
      'WORKBASKET_VIEW',
      'BUG_VIEW',
      'BUG_CREATE',
      'PR_VIEW',
      'REPORT_VIEW',
      'ITEM_ASSIGN',
      'RELEASE_APPROVE',
      'COMMENT_ADD'
    ],
    pages: [
      'forge.workbasket',
      'forge.bugs',
      'forge.prs',
      'forge.reports',
      'forge.workbasket.detail.overview',
      'forge.workbasket.detail.activity',
      'forge.workbasket.detail.comments',
      'forge.workbasket.detail.approvals'
    ],
    tabs: ['workbasket', 'bugs', 'prs', 'reports', 'overview', 'activity', 'comments', 'approvals'],
    components: [
      'workbasket.leftPanel',
      'workbasket.searchBox',
      'workbasket.filterChips',
      'workbasket.detailHeader',
      'workbasket.leadSummary',
      'reports.teamHealthCard'
    ],
    actions: {
      createBug: { enabled: true, permission: 'BUG_CREATE' },
      assignItem: { enabled: true, permission: 'ITEM_ASSIGN' },
      approveRelease: { enabled: true, permission: 'RELEASE_APPROVE' },
      addComment: { enabled: true, permission: 'COMMENT_ADD' },
      closeBug: { enabled: true, permission: 'BUG_CLOSE', reason: 'Lead can approve closure, backend must enforce final closure rule.' }
    },
    apis: {
      workbasket: '/posts',
      workitem: '/posts',
      bugs: '/posts?type=bug',
      prs: '/posts?type=pr',
      reports: '/posts?report=team',
      activity: '/comments',
      comments: '/comments'
    },
    chips: {
      workbasket: ['All', 'Bug', 'Story', 'Task', 'PR', 'Blocked'],
      bugs: ['All', 'Team', 'Critical', 'Blocked'],
      reports: ['All', 'Team', 'Release', 'Quality']
    }
  }
};

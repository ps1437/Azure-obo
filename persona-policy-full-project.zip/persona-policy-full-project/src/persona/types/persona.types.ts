export type Persona = 'QA' | 'DEV' | 'LEAD';

export type PageKey =
  | 'forge.workbasket'
  | 'forge.bugs'
  | 'forge.prs'
  | 'forge.reports'
  | 'forge.workbasket.detail.overview'
  | 'forge.workbasket.detail.activity'
  | 'forge.workbasket.detail.comments'
  | 'forge.workbasket.detail.attachments'
  | 'forge.workbasket.detail.approvals';

export type TabKey =
  | 'workbasket'
  | 'bugs'
  | 'prs'
  | 'reports'
  | 'overview'
  | 'activity'
  | 'comments'
  | 'attachments'
  | 'approvals';

export type ComponentKey =
  | 'workbasket.leftPanel'
  | 'workbasket.searchBox'
  | 'workbasket.filterChips'
  | 'workbasket.detailHeader'
  | 'workbasket.qaEvidence'
  | 'workbasket.devChecklist'
  | 'workbasket.leadSummary'
  | 'reports.teamHealthCard';

export type ActionKey =
  | 'createBug'
  | 'assignItem'
  | 'startWork'
  | 'requestReview'
  | 'approveRelease'
  | 'closeBug'
  | 'addComment'
  | 'uploadAttachment';

export type ApiKey =
  | 'workbasket'
  | 'workitem'
  | 'bugs'
  | 'prs'
  | 'reports'
  | 'activity'
  | 'comments'
  | 'attachments';

export type PermissionKey =
  | 'WORKBASKET_VIEW'
  | 'BUG_VIEW'
  | 'BUG_CREATE'
  | 'BUG_CLOSE'
  | 'PR_VIEW'
  | 'REPORT_VIEW'
  | 'ITEM_ASSIGN'
  | 'RELEASE_APPROVE'
  | 'COMMENT_ADD'
  | 'ATTACHMENT_UPLOAD';

export type QueryValue = string | number | boolean | null | undefined;

export type ActionPolicy = {
  enabled: boolean;
  permission?: PermissionKey;
  reason?: string;
};

export type PersonaPolicy = {
  persona: Persona;
  label: string;
  defaultRoute: string;
  permissions: PermissionKey[];
  pages: PageKey[];
  tabs: TabKey[];
  components: ComponentKey[];
  actions: Partial<Record<ActionKey, ActionPolicy>>;
  apis: Partial<Record<ApiKey, string>>;
  chips: Partial<Record<ApiKey, string[]>>;
};

export type MeResponse = {
  userId: string;
  name: string;
  email: string;
  persona: Persona;
};

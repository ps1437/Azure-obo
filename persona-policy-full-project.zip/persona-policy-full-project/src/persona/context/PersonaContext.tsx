import React, { createContext, useMemo } from 'react';
import { useGetMeQuery, useSwitchPersonaMutation } from '../api/meApi';
import { getPersonaPolicy } from '../engine/personaEngine';
import type { MeResponse, Persona, PersonaPolicy } from '../types/persona.types';

type PersonaContextValue = {
  me?: MeResponse;
  persona?: Persona;
  policy?: PersonaPolicy;
  isLoading: boolean;
  switchPersona: (persona: Persona) => Promise<void>;
};

export const PersonaContext = createContext<PersonaContextValue | null>(null);

export function PersonaProvider({ children }: { children: React.ReactNode }) {
  const { data: me, isLoading } = useGetMeQuery();
  const [switchPersonaMutation] = useSwitchPersonaMutation();

  const value = useMemo<PersonaContextValue>(() => {
    const policy = me ? getPersonaPolicy(me.persona) : undefined;

    return {
      me,
      persona: me?.persona,
      policy,
      isLoading,
      switchPersona: async (persona: Persona) => {
        await switchPersonaMutation(persona).unwrap();
      }
    };
  }, [me, isLoading, switchPersonaMutation]);

  return <PersonaContext.Provider value={value}>{children}</PersonaContext.Provider>;
}

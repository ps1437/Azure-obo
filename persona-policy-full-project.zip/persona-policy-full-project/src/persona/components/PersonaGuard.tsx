import React from 'react';
import { usePersonaAccess } from '../hooks/usePersonaAccess';
import type { ComponentKey, PageKey, TabKey } from '../types/persona.types';

type Props = {
  page?: PageKey;
  tab?: TabKey;
  component?: ComponentKey;
  fallback?: React.ReactNode;
  children: React.ReactNode;
};

export function PersonaGuard({ page, tab, component, fallback = null, children }: Props) {
  const access = usePersonaAccess();

  if (page && !access.canViewPage(page)) return <>{fallback}</>;
  if (tab && !access.canViewTab(tab)) return <>{fallback}</>;
  if (component && !access.canViewComponent(component)) return <>{fallback}</>;

  return <>{children}</>;
}

import React from 'react';
import { usePersonaAccess } from '../hooks/usePersonaAccess';
import type { ActionKey } from '../types/persona.types';

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  action: ActionKey;
};

export function PersonaActionButton({ action, children, className = '', ...props }: Props) {
  const { getActionState } = usePersonaAccess();
  const state = getActionState(action);

  return (
    <button
      {...props}
      disabled={!state.enabled || props.disabled}
      title={state.reason}
      className={`action-button ${className} ${!state.enabled ? 'disabled' : ''}`}
    >
      {children}
    </button>
  );
}

import { defaultApiUrls, personaPolicyConfig } from '../config/personaPolicyConfig';
import type {
  ActionKey,
  ApiKey,
  ComponentKey,
  PageKey,
  PermissionKey,
  Persona,
  PersonaPolicy,
  QueryValue,
  TabKey
} from '../types/persona.types';

export function getPersonaPolicy(persona: Persona): PersonaPolicy {
  return personaPolicyConfig[persona];
}

export function hasPermission(policy: PersonaPolicy, permission: PermissionKey): boolean {
  return policy.permissions.includes(permission);
}

export function canViewPage(policy: PersonaPolicy, page: PageKey): boolean {
  return policy.pages.includes(page);
}

export function canViewTab(policy: PersonaPolicy, tab: TabKey): boolean {
  return policy.tabs.includes(tab);
}

export function canViewComponent(policy: PersonaPolicy, component: ComponentKey): boolean {
  return policy.components.includes(component);
}

export function getActionState(policy: PersonaPolicy, action: ActionKey) {
  const actionPolicy = policy.actions[action];

  if (!actionPolicy) {
    return {
      enabled: false,
      reason: 'Action is not configured for this persona.'
    };
  }

  if (actionPolicy.permission && !hasPermission(policy, actionPolicy.permission)) {
    return {
      enabled: false,
      reason: actionPolicy.reason ?? 'You do not have permission for this action.'
    };
  }

  return {
    enabled: actionPolicy.enabled,
    reason: actionPolicy.enabled ? undefined : actionPolicy.reason ?? 'Action is disabled for this persona.'
  };
}

export function resolvePersonaApiUrl(
  policy: PersonaPolicy,
  apiKey: ApiKey,
  extraParams?: Record<string, QueryValue>
): string {
  const configuredUrl = policy.apis[apiKey] ?? defaultApiUrls[apiKey];
  const [path, existingQuery] = configuredUrl.split('?');
  const params = new URLSearchParams(existingQuery ?? '');

  Object.entries(extraParams ?? {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      params.set(key, String(value));
    }
  });

  const queryString = params.toString();
  return queryString ? `${path}?${queryString}` : path;
}

import {
  canViewComponent,
  canViewPage,
  canViewTab,
  getActionState,
  hasPermission,
  resolvePersonaApiUrl
} from '../engine/personaEngine';
import type {
  ActionKey,
  ApiKey,
  ComponentKey,
  PageKey,
  PermissionKey,
  QueryValue,
  TabKey
} from '../types/persona.types';
import { usePersona } from './usePersona';

export function usePersonaAccess() {
  const { policy } = usePersona();

  if (!policy) {
    return {
      policy: undefined,
      hasPermission: () => false,
      canViewPage: () => false,
      canViewTab: () => false,
      canViewComponent: () => false,
      getActionState: () => ({ enabled: false, reason: 'Persona is loading.' }),
      resolveApiUrl: () => ''
    };
  }

  return {
    policy,
    hasPermission: (permission: PermissionKey) => hasPermission(policy, permission),
    canViewPage: (page: PageKey) => canViewPage(policy, page),
    canViewTab: (tab: TabKey) => canViewTab(policy, tab),
    canViewComponent: (component: ComponentKey) => canViewComponent(policy, component),
    getActionState: (action: ActionKey) => getActionState(policy, action),
    resolveApiUrl: (apiKey: ApiKey, params?: Record<string, QueryValue>) =>
      resolvePersonaApiUrl(policy, apiKey, params)
  };
}

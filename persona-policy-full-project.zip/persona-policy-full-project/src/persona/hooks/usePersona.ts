import { useContext } from 'react';
import { PersonaContext } from '../context/PersonaContext';

export function usePersona() {
  const context = useContext(PersonaContext);

  if (!context) {
    throw new Error('usePersona must be used inside PersonaProvider');
  }

  return context;
}

import { createApi, fakeBaseQuery } from '@reduxjs/toolkit/query/react';
import type { MeResponse, Persona } from '../types/persona.types';

let activePersona: Persona = 'QA';

const users: Record<Persona, MeResponse> = {
  QA: {
    userId: 'u-qa-101',
    name: 'Ananya QA',
    email: 'qa@example.com',
    persona: 'QA'
  },
  DEV: {
    userId: 'u-dev-201',
    name: 'Dev Kumar',
    email: 'dev@example.com',
    persona: 'DEV'
  },
  LEAD: {
    userId: 'u-lead-301',
    name: 'Lead Sharma',
    email: 'lead@example.com',
    persona: 'LEAD'
  }
};

export const meApi = createApi({
  reducerPath: 'meApi',
  baseQuery: fakeBaseQuery(),
  tagTypes: ['Me'],
  endpoints: builder => ({
    getMe: builder.query<MeResponse, void>({
      async queryFn() {
        await new Promise(resolve => setTimeout(resolve, 250));
        return { data: users[activePersona] };
      },
      providesTags: ['Me']
    }),
    switchPersona: builder.mutation<MeResponse, Persona>({
      async queryFn(persona) {
        activePersona = persona;
        await new Promise(resolve => setTimeout(resolve, 150));
        return { data: users[activePersona] };
      },
      invalidatesTags: ['Me']
    })
  })
});

export const { useGetMeQuery, useSwitchPersonaMutation } = meApi;

# Persona Policy Full Project

A full React + RTK Query sample for persona driven UI.

## What this demonstrates

- App -> Layout -> Router -> Feature pages
- `/me` API returns only role/persona for now
- PersonaProvider derives frontend policy from config
- Later backend can return the full policy without changing pages
- Persona driven:
  - top tabs
  - route/page visibility
  - inner detail tabs
  - components
  - action buttons enabled/disabled with reason
  - API URLs
  - filter chips
  - response adapters

## Personas

- QA
- DEV
- LEAD

## Run

```bash
npm install
npm run dev
```

Open:

```txt
http://localhost:4200/forge/workbasket
```

## Important files

```txt
src/persona/api/meApi.ts
src/persona/context/PersonaContext.tsx
src/persona/config/personaPolicyConfig.ts
src/persona/engine/personaEngine.ts
src/persona/hooks/usePersona.ts
src/persona/hooks/usePersonaAccess.ts
src/persona/components/PersonaGuard.tsx
src/persona/components/PersonaActionButton.tsx
src/features/workbasket/workbasketApi.ts
src/features/workbasket/workbasketAdapters.ts
src/routes/AppRoutes.tsx
src/layout/Layout.tsx
```

## Current flow

```txt
App starts
  -> PersonaProvider calls fake /me API
  -> /me returns persona: QA / DEV / LEAD
  -> frontend loads policy from personaPolicyConfig
  -> Layout and pages render based on policy
```

## Future flow

Replace this:

```ts
const policy = me ? getPersonaPolicy(me.persona) : undefined;
```

with backend policy response:

```txt
GET /api/me/policy
```

Then backend can control tabs, actions, pages, APIs, and permissions.

## Security note

Frontend policy is for UX only. Backend must still enforce access for every API and action.
